import React, { useState } from "react";
import "./index.css";
import BreedSelector from "./components/Breedselector";
import ImageGallery from "./components/Imagegallery";

function App() {
  const [selectedBreed, setSelectedBreed] = useState("");
  const [numImages, setNumImages] = useState(0);
  const [fetchedImages, setFetchedImages] = useState([]);

  const handleBreedChange = (breed) => {
    setSelectedBreed(breed);
  };

  const handleNumImagesChange = (num) => {
    setNumImages(num);
  };

  const handleFetchedImagesChange = (images) => {
    setFetchedImages(images);
  };

  return (
    <div className="container">
      <BreedSelector
        onBreedChange={handleBreedChange}
        onNumImagesChange={handleNumImagesChange}
        onFetchedImagesChange={handleFetchedImagesChange}
      />
      <ImageGallery images={fetchedImages} />
    </div>
  );
}

export default App;
