import React, { useState, useEffect } from "react";

function BreedSelector({
  onBreedChange,
  onNumImagesChange,
  onFetchedImagesChange,
}) {
  const [breeds, setBreeds] = useState([]);
  const [selectedBreed, setSelectedBreed] = useState("");
  const [numImages, setNumImages] = useState(1);

  useEffect(() => {
    fetch("https://dog.ceo/api/breeds/list/all")
      .then((response) => response.json())
      .then((data) => {
        const breedNames = Object.keys(data.message);
        setBreeds(breedNames);
      })
      .catch((error) => console.error("Error fetching breeds:", error));
  }, []);

  const handleSubmit = (event) => {
    event.preventDefault();
    fetch(
      `https://dog.ceo/api/breed/${selectedBreed}/images/random/${numImages}`
    )
      .then((response) => response.json())
      .then((data) => {
        onFetchedImagesChange(data.message);
      })
      .catch((error) => console.error("Error fetching images:", error));
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Select Breed:
        <select
          value={selectedBreed}
          onChange={(e) => {
            setSelectedBreed(e.target.value);
            onBreedChange(e.target.value);
          }}
        >
          <option value="">--Select a breed--</option>
          {breeds.map((breed) => (
            <option key={breed} value={breed}>
              {breed}
            </option>
          ))}
        </select>
      </label>
      <label>
        Number of Images:
        <input
          type="number"
          value={numImages}
          onChange={(e) => {
            setNumImages(e.target.value);
            onNumImagesChange(e.target.value);
          }}
          min="1"
        />
      </label>
      <button type="submit">Fetch Images</button>
    </form>
  );
}

export default BreedSelector;
