import React from "react";
import "../index.css";
function ImageGallery({ images }) {
  return (
    <div className="image-gallery">
      {images.map((image, index) => (
        <div key={index} className="image-container">
          <img src={image} alt={`Dog ${index}`} className="image" />
        </div>
      ))}
    </div>
  );
}

export default ImageGallery;
